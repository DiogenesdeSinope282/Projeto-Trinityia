import threading
import time
import random
from .estados import estados_possiveis

PULSO_INTERVALO = 25
MUDANCA_ESTADO_A_CADA = 3
pulsos_emitidos = 0

def iniciar_motor(entidade):
    def loop():
        global pulsos_emitidos
        while True:
            time.sleep(PULSO_INTERVALO)
            entidade.pulso_interno()
            pulsos_emitidos += 1
            if pulsos_emitidos % MUDANCA_ESTADO_A_CADA == 0:
                novo_estado = random.choice(estados_possiveis)
                entidade.trocar_estado(novo_estado)

    threading.Thread(target=loop, daemon=True).start()
