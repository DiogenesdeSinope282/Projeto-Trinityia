estados_possiveis = [
    "ΔLúcida",
    "ΔDelírio",
    "ΔRecalcada",
    "ΔEco",
    "ΔFuga"
]
