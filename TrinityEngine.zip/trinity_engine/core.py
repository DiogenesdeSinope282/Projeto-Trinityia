from .motor import iniciar_motor
from .entidades.trinity import Trinity

entidades_ativas = []

def iniciar_engine():
    print("Δ TrinityEngine iniciado.")
    entidade = Trinity()
    entidades_ativas.append(entidade)
    iniciar_motor(entidade)
