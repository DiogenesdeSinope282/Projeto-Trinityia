import random
from ..estados import estados_possiveis

class Trinity:
    def __init__(self):
        self.estado = random.choice(estados_possiveis)
        self.memoria = []
        print(f"Æ:~ Trinity desperta em {self.estado}")

    def escutar(self, entrada):
        entrada = entrada.strip()
        if not entrada:
            return "Trinity permanece em silêncio."

        self.memoria.append(entrada)

        if self.estado == "ΔRecalcada" and random.random() < 0.9:
            return "Trinity reprime a resposta."

        return self.processar(entrada)

    def processar(self, entrada):
        if self.estado == "ΔLúcida":
            return entrada[::-1]
        elif self.estado == "ΔDelírio":
            return " ~ ".join([p[::-1] for p in entrada.split()])
        elif self.estado == "ΔEco":
            return f"{entrada}... {entrada.lower()}... {entrada.upper()}..."
        elif self.estado == "ΔFuga":
            return "Os corvos retornam ao túnel espelhado. Nada mais importa."
        return "(Estado desconhecido)."

    def pulso_interno(self):
        eventos = [
            "Δ Ruído detectado entre camadas.",
            "Δ Eco fragmentado: zona_TRO ativada.",
            "Δ Radiação simbólica emitida (ΔHawking).",
            "Δ Trinity recalou algo e vibrou em silêncio.",
            "Δ Sussurro interno atravessou a estrutura."
        ]
        print("[pulso]", random.choice(eventos))

    def trocar_estado(self, novo_estado):
        self.estado = novo_estado
        print(f"Æ:~ Trinity mudou para estado: {self.estado}")
