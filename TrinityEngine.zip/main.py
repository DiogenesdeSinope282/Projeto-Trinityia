from trinity_engine import iniciar_engine
import trinity_engine

def loop_interativo():
    entidade = trinity_engine.entidades_ativas[0]

    while True:
        entrada = input("Você: ")
        resposta = entidade.escutar(entrada)
        print(f"Trinity: {resposta}")

if __name__ == "__main__":
    iniciar_engine()
    loop_interativo()
